# JARVIS V1.3 — Gemini AI

This version adds Gemini cloud AI to the JARVIS V1.2 project.

## What changed
- General questions are sent to Gemini when a key is saved.
- The app asks Gemini to reply in the same language as the user.
- Gemini API key is stored locally in Android SharedPreferences and is NOT hardcoded in source.
- Built-in JARVIS commands (creator, time, weather, alarm, timer) still work locally.
- Includes the JARVIS animation GIF and GitHub Actions APK build workflow.

## Important security note
Do NOT commit your personal API key into GitHub source code.
This prototype stores the key locally on the phone. For a public production app, use a secure backend so the key is not exposed in the APK.

## Current model
The app calls `gemini-2.5-flash-lite` through the Gemini Developer API.

Google currently lists a free tier for Gemini 2.5 Flash-Lite; quotas/rates can change. See Google's current pricing documentation:
https://ai.google.dev/gemini-api/docs/pricing

If your Google account/project is not eligible for API access, use an eligible account rather than attempting to bypass age or account restrictions.

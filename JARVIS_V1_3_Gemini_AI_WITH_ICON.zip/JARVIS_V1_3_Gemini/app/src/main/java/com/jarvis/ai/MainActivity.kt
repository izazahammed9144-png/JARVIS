package com.jarvis.ai

import android.app.Activity
import android.content.Intent
import android.os.Bundle
import android.content.Context
import android.content.SharedPreferences
import android.speech.RecognizerIntent
import android.speech.tts.TextToSpeech
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import java.net.HttpURLConnection
import java.net.URLEncoder
import java.net.URL
import java.util.Locale
import org.json.JSONObject

class MainActivity : ComponentActivity(), TextToSpeech.OnInitListener {
    private lateinit var tts: TextToSpeech
    private var selectedLanguage = "bn"
    private val voiceRequest = 1001
    private lateinit var prefs: SharedPreferences

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        tts = TextToSpeech(this, this)
        prefs = getSharedPreferences("jarvis_settings", Context.MODE_PRIVATE)

        setContent {
            JarvisScreen(
                onSpeak = { startVoiceInput() },
                onLanguage = { selectedLanguage = it },
                onTextCommand = { handleCommand(it) },
                initialApiKey = prefs.getString("gemini_api_key", "") ?: "",
                onSaveApiKey = {
                    prefs.edit().putString("gemini_api_key", it.trim()).apply()
                    saved = true
                }
            )
        }
    }

    override fun onInit(status: Int) {
        if (status == TextToSpeech.SUCCESS) setTtsLanguage(selectedLanguage)
    }

    private fun setTtsLanguage(lang: String) {
        val locale = when (lang) {
            "hi" -> Locale("hi", "IN")
            "en" -> Locale.US
            else -> Locale("bn", "IN")
        }
        tts.language = locale
    }

    private fun speak(text: String) {
        setTtsLanguage(selectedLanguage)
        tts.speak(text, TextToSpeech.QUEUE_FLUSH, null, "jarvis")
    }

    private fun startVoiceInput() {
        val intent = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
            putExtra(
                RecognizerIntent.EXTRA_LANGUAGE,
                when (selectedLanguage) {
                    "hi" -> "hi-IN"
                    "en" -> "en-IN"
                    else -> "bn-IN"
                }
            )
            putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL,
                RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
            putExtra(RecognizerIntent.EXTRA_PROMPT, "Speak to JARVIS")
        }
        startActivityForResult(intent, voiceRequest)
    }

    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == voiceRequest && resultCode == Activity.RESULT_OK) {
            val text = data?.getStringArrayListExtra(RecognizerIntent.EXTRA_RESULTS)
                ?.firstOrNull() ?: return
            handleCommand(text)
        }
    }

    private fun handleCommand(command: String) {
        val q = command.trim().lowercase(Locale.getDefault())

        when {
            q.contains("who made you") ||
            q.contains("who created you") ||
            q.contains("কে বানিয়েছে") ||
            q.contains("কে বানিয়েছে") ||
            q.contains("তোমাকে কে") -> {
                speak(
                    when (selectedLanguage) {
                        "en" -> "I was created by Izaz Ahammed."
                        "hi" -> "मुझे Izaz Ahammed ने बनाया है।"
                        else -> "আমাকে বানিয়েছে Izaz Ahammed।"
                    }
                )
            }

            q.contains("izaz") && (q.contains("born") || q.contains("জন্ম") || q.contains("birthday")) -> {
                speak(
                    when (selectedLanguage) {
                        "en" -> "Izaz Ahammed was born on 26 April 2009."
                        "hi" -> "Izaz Ahammed का जन्म 26 अप्रैल 2009 को हुआ था।"
                        else -> "Izaz Ahammed-এর জন্ম ২৬ এপ্রিল, ২০০৯।"
                    }
                )
            }

            q.contains("izaz") && (q.contains("ideology") || q.contains("আদর্শ") || q.contains("বিশ্বাস")) -> {
                speak(
                    when (selectedLanguage) {
                        "en" -> "Izaz Ahammed identifies with leftist, communist and socialist ideology."
                        "hi" -> "Izaz Ahammed लेफ्टिस्ट, कम्युनिस्ट और सोशलिस्ट विचारधारा से जुड़े हैं।"
                        else -> "Izaz Ahammed লেফটিস্ট, কমিউনিস্ট এবং সোশালিস্ট মতাদর্শে বিশ্বাস করেন।"
                    }
                )
            }

            q.contains("time") || q.contains("সময়") || q.contains("সময়") || q.contains("समय") -> {
                val now = java.text.SimpleDateFormat("hh:mm a", Locale.getDefault()).format(java.util.Date())
                speak(
                    when (selectedLanguage) {
                        "en" -> "The current time is $now."
                        "hi" -> "अभी समय $now है।"
                        else -> "এখন সময় $now।"
                    }
                )
            }

            q.contains("alarm") || q.contains("অ্যালার্ম") || q.contains("अलार्म") -> {
                try {
                    startActivity(Intent(android.provider.AlarmClock.ACTION_SET_ALARM))
                    speak(
                        when (selectedLanguage) {
                            "en" -> "The alarm screen is open."
                            "hi" -> "अलार्म स्क्रीन खोल दी है।"
                            else -> "অ্যালার্মের স্ক্রিন খুলে দিয়েছি।"
                        }
                    )
                } catch (_: Exception) {
                    speak("Alarm is not available on this device.")
                }
            }

            q.contains("timer") || q.contains("টাইমার") || q.contains("टाइमर") -> {
                try {
                    startActivity(Intent(android.provider.AlarmClock.ACTION_SET_TIMER))
                    speak(
                        when (selectedLanguage) {
                            "en" -> "The timer screen is open."
                            "hi" -> "टाइमर स्क्रीन खोल दी है।"
                            else -> "টাইমারের স্ক্রিন খুলে দিয়েছি।"
                        }
                    )
                } catch (_: Exception) {
                    speak("Timer is not available on this device.")
                }
            }

            q.contains("weather") || q.contains("আবহাওয়া") || q.contains("আবহাওয়া") ||
            q.contains("मौसम") -> {
                val city = extractCity(command)
                fetchWeather(city)
            }

            else -> {
                askGemini(command)
            }
        }
    }


    private fun askGemini(command: String) {
        val apiKey = prefs.getString("gemini_api_key", "")?.trim().orEmpty()
        if (apiKey.isBlank()) {
            speak(
                when (selectedLanguage) {
                    "en" -> "Gemini AI is ready, but your API key has not been added yet."
                    "hi" -> "Gemini AI तैयार है, लेकिन API key अभी जोड़ी नहीं गई है।"
                    else -> "Gemini AI প্রস্তুত আছে, কিন্তু API key এখনো যোগ করা হয়নি।"
                }
            )
            return
        }

        Thread {
            try {
                val endpoint =
                    "https://generativelanguage.googleapis.com/v1beta/models/" +
                    "gemini-2.5-flash-lite:generateContent?key=$apiKey"

                val body = JSONObject().apply {
                    put("contents", org.json.JSONArray().put(
                        JSONObject().apply {
                            put("parts", org.json.JSONArray().put(
                                JSONObject().put(
                                    "text",
                                    "You are JARVIS, a helpful personal assistant. " +
                                    "Reply in the same language as the user. Be concise and friendly. " +
                                    "User said: $command"
                                )
                            ))
                        }
                    ))
                }

                val conn = (URL(endpoint).openConnection() as HttpURLConnection)
                conn.requestMethod = "POST"
                conn.setRequestProperty("Content-Type", "application/json")
                conn.doOutput = true
                conn.outputStream.use { it.write(body.toString().toByteArray(Charsets.UTF_8)) }

                val code = conn.responseCode
                val stream = if (code in 200..299) conn.inputStream else conn.errorStream
                val response = stream.bufferedReader().use { it.readText() }

                if (code !in 200..299) {
                    runOnUiThread {
                        speak("Gemini API error. Please check your API key and quota.")
                    }
                    return@Thread
                }

                val json = JSONObject(response)
                val answer = json.getJSONArray("candidates")
                    .getJSONObject(0)
                    .getJSONObject("content")
                    .getJSONArray("parts")
                    .getJSONObject(0)
                    .getString("text")
                    .trim()

                runOnUiThread { speak(answer) }
            } catch (_: Exception) {
                runOnUiThread {
                    speak("I could not connect to Gemini right now.")
                }
            }
        }.start()
    }

    private fun extractCity(command: String): String {
        val patterns = listOf(
            Regex("weather in (.+)", RegexOption.IGNORE_CASE),
            Regex("আবহাওয়া (.+)", RegexOption.IGNORE_CASE),
            Regex("আবহাওয়া (.+)", RegexOption.IGNORE_CASE),
            Regex("मौसम (.+)", RegexOption.IGNORE_CASE)
        )
        return patterns.firstNotNullOfOrNull { it.find(command)?.groupValues?.getOrNull(1) }
            ?.trim()?.ifBlank { "Kolkata" } ?: "Kolkata"
    }

    private fun fetchWeather(city: String) {
        Thread {
            try {
                val geoUrl = URL(
                    "https://geocoding-api.open-meteo.com/v1/search?name=" +
                    URLEncoder.encode(city, "UTF-8") + "&count=1&language=en&format=json"
                )
                val geo = (geoUrl.openConnection() as HttpURLConnection).run {
                    requestMethod = "GET"
                    inputStream.bufferedReader().use { it.readText() }
                }
                val results = JSONObject(geo).optJSONArray("results")
                if (results == null || results.length() == 0) {
                    runOnUiThread { speak("I could not find that city.") }
                    return@Thread
                }

                val place = results.getJSONObject(0)
                val lat = place.getDouble("latitude")
                val lon = place.getDouble("longitude")

                val weatherUrl = URL(
                    "https://api.open-meteo.com/v1/forecast?latitude=$lat&longitude=$lon" +
                    "&current=temperature_2m,weather_code&timezone=auto"
                )
                val weather = (weatherUrl.openConnection() as HttpURLConnection).run {
                    requestMethod = "GET"
                    inputStream.bufferedReader().use { it.readText() }
                }
                val current = JSONObject(weather).getJSONObject("current")
                val temp = current.getDouble("temperature_2m")
                val unit = current.optString("temperature_2m", "°C")
                val answer = when (selectedLanguage) {
                    "en" -> "The current temperature in $city is $temp degrees Celsius."
                    "hi" -> "$city में अभी तापमान $temp डिग्री सेल्सियस है।"
                    else -> "$city-তে এখন তাপমাত্রা $temp ডিগ্রি সেলসিয়াস।"
                }
                runOnUiThread { speak(answer) }
            } catch (_: Exception) {
                runOnUiThread { speak("Weather data could not be loaded right now.") }
            }
        }.start()
    }

    override fun onDestroy() {
        tts.stop()
        tts.shutdown()
        super.onDestroy()
    }
}

@Composable
fun JarvisScreen(
    onSpeak: () -> Unit,
    onLanguage: (String) -> Unit,
    onTextCommand: (String) -> Unit,
    initialApiKey: String = "",
    onSaveApiKey: (String) -> Unit = {}
) {
    var text by remember { mutableStateOf("") }
    var apiKey by remember { mutableStateOf(initialApiKey) }
    var saved by remember { mutableStateOf(false) }
    MaterialTheme {
        Surface(modifier = Modifier.fillMaxSize()) {
            Column(
                modifier = Modifier
                    .padding(20.dp)
                    .verticalScroll(rememberScrollState())
            ) {
                Text("JARVIS", style = MaterialTheme.typography.headlineLarge)
                Text("Your Personal AI Assistant", style = MaterialTheme.typography.bodyLarge)
                Spacer(Modifier.height(18.dp))

                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    Button(onClick = { onLanguage("bn") }) { Text("বাংলা") }
                    Button(onClick = { onLanguage("en") }) { Text("English") }
                    Button(onClick = { onLanguage("hi") }) { Text("हिन्दी") }
                }

                Spacer(Modifier.height(18.dp))

                Button(
                    onClick = onSpeak,
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Text("🎙 Speak to JARVIS")
                }

                Spacer(Modifier.height(12.dp))

                OutlinedTextField(
                    value = text,
                    onValueChange = { text = it },
                    modifier = Modifier.fillMaxWidth(),
                    label = { Text("Type a command") }
                )

                Spacer(Modifier.height(8.dp))

                Button(
                    onClick = { if (text.isNotBlank()) onTextCommand(text) },
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Text("Ask JARVIS")
                }

                Spacer(Modifier.height(18.dp))
                Text("Gemini AI", style = MaterialTheme.typography.titleMedium)
                OutlinedTextField(
                    value = apiKey,
                    onValueChange = { apiKey = it; saved = false },
                    modifier = Modifier.fillMaxWidth(),
                    label = { Text("Gemini API key") },
                    singleLine = true
                )
                Spacer(Modifier.height(8.dp))
                Button(
                    onClick = { onSaveApiKey(apiKey) },
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Text(if (saved) "API key saved" else "Save API key")
                }

                Spacer(Modifier.height(20.dp))
                Text("Examples:", style = MaterialTheme.typography.titleMedium)
                Text("• তোমাকে কে বানিয়েছে?\n• Izaz-এর জন্মদিন কবে?\n• Izaz কোন ideology-তে বিশ্বাস করে?\n• What is the time?\n• Weather in Kolkata\n• Set an alarm\n• Set a timer")
            }
        }
    }
}

JARVIS V1.3 - App Icon

The JARVIS app icon is already included in the Android project.
Launcher icon resources are under:
app/src/main/res/mipmap-mdpi/ic_launcher.png
app/src/main/res/mipmap-hdpi/ic_launcher.png
app/src/main/res/mipmap-xhdpi/ic_launcher.png
app/src/main/res/mipmap-xxhdpi/ic_launcher.png
app/src/main/res/mipmap-xxxhdpi/ic_launcher.png

AndroidManifest.xml is configured to use @mipmap/ic_launcher.
